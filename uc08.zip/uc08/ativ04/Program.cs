﻿float opc, n1, n2, result;

Console.Write("digite o 1°num.: ");
n1 = float.Parse(Console.ReadLine());

Console.Write("\n digite o 2°num.: ");
n2 = float.Parse(Console.ReadLine());

Console.WriteLine("\n=== calculadora===");
Console.WriteLine("\n 1. soma");
Console.WriteLine(" 2. subtração");
Console.WriteLine(" 3. divisão");
Console.WriteLine(" 4. multiplicação");

Console.Write("\n digite o num. da operação desjada: ");
opc = float.Parse(Console.ReadLine());

switch (opc)
{
    case 1:
        Console.WriteLine($"\n a soma de {n1} + {n2} é: {n1 + n2}");
        break;

    case 2:
        Console.WriteLine($"\n a subtração de {n1} - {n2} é: {n1 - n2}");
        break;

    case 3:
        Console.WriteLine($"\n a divisão de {n1} / {n2} é: {n1 / n2}");
        break;

    case 4:
        Console.WriteLine($"\n a multiplicação de {n1} * {n2} é: {n1 * n2}");
        break;

    default:
        Console.WriteLine("\n opção invalida");
        break;


    
}