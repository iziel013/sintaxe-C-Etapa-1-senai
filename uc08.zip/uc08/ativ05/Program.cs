﻿double real, dolar, euro, pesoarg, ienejapa, opc;

Console.WriteLine("=== Conversor de Moedas ===");

Console.Write("\nDigite o valor em Reais: ");
real = double.Parse(Console.ReadLine());

Console.WriteLine("\n 1. Real para Dólar ");
Console.WriteLine(" 2. Real para euro ");
Console.WriteLine(" 3. Real para peso argentino");
Console.WriteLine(" 4. Real para iene japones");

Console.Write("\n digite o num. da operação desjada: ");
opc = double.Parse(Console.ReadLine());

switch (opc)
{
    case 1:
        dolar = real / 5.25;

        Console.WriteLine($" o valor de R${real} é equivalente a ${dolar}");
        break;

    case 2:
        euro = real / 5.50;

        Console.WriteLine($" o valor de R${real} é equivalente a €{euro}");
        break;

    case 3:
        pesoarg = real / 0.05;

        Console.WriteLine($" o valor de R${real} é equivalente a ${pesoarg} peso argentino");
        break;

    case 4:
        ienejapa = real / 0.04;

        Console.WriteLine($" o valor de R${real} é equivalente a ¥{ienejapa} iene japones");
        break;

    default:
        Console.WriteLine("\n opção invalida");
        break;
}