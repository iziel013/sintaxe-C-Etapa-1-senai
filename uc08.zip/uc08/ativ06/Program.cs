﻿double c, f, k, opc;

Console.WriteLine("=== escala termografica ===");


Console.WriteLine("\n 1. celsius para fahrenheit ");
Console.WriteLine(" 2. celsius para kelvin ");


Console.Write("\n digite o num. da operação desjada: ");
opc = float.Parse(Console.ReadLine());

Console.Write("Digite a temperatura em Celsius: ");
c = double.Parse(Console.ReadLine());

switch (opc)
{
    case 1:
        f = (c * 1.8) + 32;

        Console.WriteLine($" a temp. {c}°C é equivalente a {f}°F");
        break;

    case 2:
       k = c + 273.15;

        Console.WriteLine($" a temp. {c}°C é equivalente a {k}°K");
        break;

    default:
        Console.WriteLine("\n opção invalida");
        break;
}

