﻿double c, f;

Console.WriteLine("=== Conversor de Celsius para Fahrenheit ===");

Console.WriteLine("\nDigite a temperatura em Celsius: ");
c = double.Parse(Console.ReadLine());

f = (c * 1.8) + 32;

Console.WriteLine($" a temp. {c}°C é equivalente a {f}°F");