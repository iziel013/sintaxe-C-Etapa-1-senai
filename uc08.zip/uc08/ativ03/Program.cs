﻿double nota1, nota2, nota3, media;

Console.WriteLine("=== Calculadora Ar ===");

Console.WriteLine("\nDigite a primeira nota: ");
nota1 = double.Parse(Console.ReadLine());

Console.WriteLine("\nDigite a segunda nota: ");
nota2 = double.Parse(Console.ReadLine());

Console.WriteLine("\nDigite a terceira nota: ");
nota3 = double.Parse(Console.ReadLine());


media = (nota1 + nota2 + nota3) / 3;

if(media <= 5)
{
    Console.WriteLine($"sua media é {media} e você foi reprovado");
}
else
{
    Console.WriteLine($"sua media é {media} e você foi aprovado");
}




