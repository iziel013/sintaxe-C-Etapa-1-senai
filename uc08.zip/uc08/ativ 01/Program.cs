﻿double num1, num2, num3, media;

Console.WriteLine("=== Calculadora Aritmética ===");

Console.WriteLine("\nDigite o primeiro número: ");
num1 = double.Parse(Console.ReadLine());

Console.WriteLine("\nDigite o segundo número: ");
num2 = double.Parse(Console.ReadLine());

Console.WriteLine("\nDigite o terceiro número: ");
num3 = double.Parse(Console.ReadLine());


media = (num1 + num2 + num3) / 3;

Console.WriteLine($"\nA média dos três números é: {media}");